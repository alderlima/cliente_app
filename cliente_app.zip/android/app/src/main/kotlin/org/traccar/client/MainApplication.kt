package org.traccar.client

import android.app.Application

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
